import InfoSection from '@/components/DashBoard/InfoSection'
import React from 'react'

const page = () => {
  return (
    <div className='w-full'>
      {/* tabs */}
      <div className='mt-4 scroll-pb-16'>
        <InfoSection />

      </div>
    </div>
  )
}

export default page