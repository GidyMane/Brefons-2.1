
import React from 'react'

const page = () => {
  return (
    <div className='w-full'>
      <div className='flex items-center justify-center mt-4 text-gray-900'>Activities Coming Soon</div>

    </div>
  )
}

export default page