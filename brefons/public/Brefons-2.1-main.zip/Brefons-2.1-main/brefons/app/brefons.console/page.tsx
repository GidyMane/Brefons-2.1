import Dashboard from '@/components/DashBoard/dashboard'
import React from 'react'

const page = () => {
  return (
    <div className='w-full mt-4 text-gray-900'><Dashboard/></div>
  )
}

export default page